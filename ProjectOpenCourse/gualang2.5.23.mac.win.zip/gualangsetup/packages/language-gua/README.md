# language-gua

gualang syntax hightlighting support for github atom editor
