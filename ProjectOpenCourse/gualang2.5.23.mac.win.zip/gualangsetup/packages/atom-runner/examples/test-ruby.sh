#!/usr/bin/env ruby

puts "hello world!"
